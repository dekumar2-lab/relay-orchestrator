package com.relay.orchestrator.connection;

import com.github.copilot.CopilotClient;
import com.github.copilot.CopilotSession;
import com.github.copilot.generated.AssistantMessageEvent;
import com.github.copilot.rpc.CopilotClientOptions;
import com.github.copilot.rpc.PermissionHandler;
import com.github.copilot.rpc.SessionConfig;
import com.relay.orchestrator.logging.LogBroadcaster;
import com.relay.orchestrator.logging.LogEvent;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientException;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

@Service
public class CopilotConnectionChecker implements LlmConnectionChecker {

    private final LogBroadcaster broadcaster;
    private final ConnectionStatusService connectionStatusService;
    private final RestClient restClient = RestClient.create();

    public CopilotConnectionChecker(LogBroadcaster broadcaster, ConnectionStatusService connectionStatusService) {
        this.broadcaster = broadcaster;
        this.connectionStatusService = connectionStatusService;
    }

    @Override
    public void validate(ConnectionConfig config) {
        try {
            if (!validateWorkspaceDir(config)) {
                connectionStatusService.markFailure(config.getProvider().name());
                return;
            }
            String login = validateGithubToken(config);
            if (login == null) {
                connectionStatusService.markFailure(config.getProvider().name());
                return;
            }
            validateCopilotAccess(config, login);
            connectionStatusService.markSuccess(config.getProvider().name());
        } catch (Exception e) {
            broadcaster.publish(LogEvent.error("Copilot check failed: " + e.getMessage()));
            connectionStatusService.markFailure(config.getProvider().name());
        }
    }

    private boolean validateWorkspaceDir(ConnectionConfig config) {
        broadcaster.publish(LogEvent.info("Checking workspace directory..."));
        if (config.getWorkspaceDir() == null || config.getWorkspaceDir().isBlank()) {
            broadcaster.publish(LogEvent.warn(
                    "No workspace directory set - fine for this test, but set one before Phase 1's indexing step"));
            return true;
        }
        Path dir = Path.of(config.getWorkspaceDir());
        if (!Files.isDirectory(dir) || !Files.isWritable(dir)) {
            broadcaster.publish(LogEvent.error(
                    "Workspace directory does not exist or is not writable: " + dir
                            + " - create it first or point at a folder you own"));
            return false;
        }
        broadcaster.publish(LogEvent.success("Workspace directory OK: " + dir));
        return true;
    }

    private String validateGithubToken(ConnectionConfig config) {
        broadcaster.publish(LogEvent.info("Validating GitHub token..."));

        if (config.getGithubToken() == null || config.getGithubToken().isBlank()) {
            broadcaster.publish(
                    LogEvent.error("No GitHub token entered - generate one at github.com/settings/tokens?type=beta"));
            return null;
        }

        try {
            Map<?, ?> user = restClient.get()
                    .uri("https://api.github.com/user")
                    .header("Authorization", "Bearer " + config.getGithubToken())
                    .header("Accept", "application/vnd.github+json")
                    .retrieve()
                    .body(Map.class);

            String login = user != null ? String.valueOf(user.get("login")) : "unknown";
            broadcaster.publish(LogEvent.success("GitHub token valid - authenticated as " + login));
            return login;

        } catch (RestClientException e) {
            String hint = e.getMessage() != null && e.getMessage().contains("401")
                    ? " (401 Unauthorized - token invalid or expired, regenerate at github.com/settings/tokens)"
                    : "";
            broadcaster.publish(LogEvent.error("GitHub token check failed: " + e.getMessage() + hint));
            return null;
        }
    }

    private void validateCopilotAccess(ConnectionConfig config, String login) {
        broadcaster.publish(LogEvent.info("Checking Copilot access for " + login + "..."));
        broadcaster.publish(LogEvent.info(
                "Requires the Copilot CLI installed locally (npm install -g @github/copilot) - the SDK drives it under the hood"));

        CopilotClientOptions options = new CopilotClientOptions()
                .setGitHubToken(config.getGithubToken())
                .setUseLoggedInUser(false);

        try (CopilotClient client = new CopilotClient(options)) {
            client.start().get(30, TimeUnit.SECONDS);
            broadcaster.publish(LogEvent.info("Copilot CLI process started"));

            SessionConfig sessionConfig = new SessionConfig()
                    .setOnPermissionRequest(PermissionHandler.APPROVE_ALL)
                    .setModel(config.getModel());
            CopilotSession session = client.createSession(sessionConfig).get(30, TimeUnit.SECONDS);

            AtomicReference<String> reply = new AtomicReference<>("");
            session.on(AssistantMessageEvent.class, msg -> reply.set(reply.get() + msg.getData().content()));

            broadcaster.publish(LogEvent.info("Sending test prompt to model: " + config.getModel()));
            session.send("Reply with the single word OK and nothing else.").get(30, TimeUnit.SECONDS);

            if (!reply.get().isBlank()) {
                broadcaster.publish(LogEvent.success("Copilot replied: " + reply.get().trim()));
                broadcaster
                        .publish(LogEvent.success("Connection validated - GitHub and Copilot LLM are both reachable"));
            } else {
                broadcaster.publish(LogEvent.warn(
                        "Copilot session started but returned no reply - check the model name is valid for your account"));
                throw new IllegalStateException("Copilot session returned no reply");
            }

        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            broadcaster.publish(LogEvent.error("Copilot check failed: " + e.getMessage()
                    + " - verify: (1) the Copilot CLI is installed and on PATH (`copilot --version`), "
                    + "(2) your token has the 'Copilot Requests' permission, "
                    + "(3) your GitHub account has an active Copilot seat"));
            throw new IllegalStateException("Copilot validation interrupted", e);
        } catch (java.util.concurrent.ExecutionException e) {
            broadcaster.publish(LogEvent.error("Copilot check failed: " + e.getMessage()
                    + " - verify: (1) the Copilot CLI is installed and on PATH (`copilot --version`), "
                    + "(2) your token has the 'Copilot Requests' permission, "
                    + "(3) your GitHub account has an active Copilot seat"));
            throw new IllegalStateException("Copilot validation execution failed", e);
        } catch (java.util.concurrent.TimeoutException e) {
            broadcaster.publish(LogEvent.error("Copilot check failed: " + e.getMessage()
                    + " - verify: (1) the Copilot CLI is installed and on PATH (`copilot --version`), "
                    + "(2) your token has the 'Copilot Requests' permission, "
                    + "(3) your GitHub account has an active Copilot seat"));
            throw new IllegalStateException("Copilot validation timed out", e);
        } catch (Exception e) {
            broadcaster.publish(LogEvent.error(
                    "Copilot check failed: " + e.getMessage()
                            + " - verify: (1) the Copilot CLI is installed and on PATH (`copilot --version`), "
                            + "(2) your token has the 'Copilot Requests' permission, "
                            + "(3) your GitHub account has an active Copilot seat"));
            throw e;
        }
    }
}
