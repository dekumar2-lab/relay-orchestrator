package com.relay.orchestrator.config;

import org.yaml.snakeyaml.DumperOptions;
import org.yaml.snakeyaml.Yaml;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import jakarta.annotation.PostConstruct;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

@Component
public class AppConfigManager {

    private static final Logger log = LoggerFactory.getLogger(AppConfigManager.class);

    // Prefer the project-local config file, then fall back to
    // ~/.relay-orchestrator/config.yml
    private final Path configPath = resolveConfigPath();

    private static Path resolveConfigPath() {
        Path projectConfig = Paths.get("config.yml").toAbsolutePath().normalize();
        if (Files.exists(projectConfig)) {
            return projectConfig;
        }
        Path homeConfig = Paths.get(System.getProperty("user.home"), ".relay-orchestrator", "config.yml");
        return homeConfig;
    }

    // Loaded operational values stored in-memory
    private String githubToken = "";
    private String anthropicApiKey = "";
    private String workspaceDir = "";
    private String model = "claude-sonnet-4.5";
    private int requestBudget = 20;
    private String provider = "GITHUB_COPILOT";
    private final List<RepositoryConfig> repositories = new ArrayList<>();

    @PostConstruct
    public void init() {
        loadSettingsFromDisk();
    }

    /**
     * Reads and parses YAML settings from disk. Falls back safely if missing.
     */
    @SuppressWarnings("unchecked")
    public synchronized void loadSettingsFromDisk() {
        if (!Files.exists(configPath)) {
            log.info("No configuration file found at {}. Initializing defaults.", configPath);
            flushSettingsToDisk();
            return;
        }

        try (InputStream input = Files.newInputStream(configPath)) {
            Yaml yaml = new Yaml();
            Map<String, Object> data = yaml.load(input);
            if (data == null)
                return;

            // Load Phase 1 parameters safely
            this.githubToken = (String) data.getOrDefault("githubToken", "");
            this.anthropicApiKey = (String) data.getOrDefault("anthropicApiKey", "");
            this.workspaceDir = (String) data.getOrDefault("workspaceDir", "");
            this.model = (String) data.getOrDefault("model", "claude-sonnet-4.5");
            this.provider = String.valueOf(data.getOrDefault("provider", "GITHUB_COPILOT"));
            this.requestBudget = (Integer) data.getOrDefault("requestBudget", 20);

            // Load and transform Phase 2 repositories list mapping arrays
            this.repositories.clear();
            List<Map<String, Object>> repoList = (List<Map<String, Object>>) data.get("repositories");
            if (repoList != null) {
                for (Map<String, Object> repoMap : repoList) {
                    RepositoryConfig repo = new RepositoryConfig();
                    repo.setId((String) repoMap.get("id"));
                    repo.setPath((String) repoMap.get("path"));

                    if (repoMap.get("sourceType") != null) {
                        repo.setSourceType(SourceType.valueOf((String) repoMap.get("sourceType")));
                    }
                    if (repoMap.get("status") != null) {
                        repo.setStatus(RepoStatus.valueOf((String) repoMap.get("status")));
                    }
                    if (repoMap.get("lastIndexed") != null) {
                        repo.setLastIndexed(LocalDateTime.parse((String) repoMap.get("lastIndexed"),
                                DateTimeFormatter.ISO_LOCAL_DATE_TIME));
                    }
                    this.repositories.add(repo);
                }
            }
            log.info("Successfully loaded {} repositories from settings config.", repositories.size());
        } catch (Exception e) {
            log.error("Failed to safely read config.yml file from folder context structure", e);
        }
    }

    /**
     * Serializes the current in-memory configurations directly into structured YAML
     * markup.
     */
    public synchronized void flushSettingsToDisk() {
        try {
            // Ensure parent directory infrastructure exists securely
            Files.createDirectories(configPath.getParent());

            Map<String, Object> rawData = new LinkedHashMap<>();
            rawData.put("provider", this.provider);
            rawData.put("githubToken", this.githubToken);
            rawData.put("anthropicApiKey", this.anthropicApiKey);
            rawData.put("workspaceDir", this.workspaceDir);
            rawData.put("model", this.model);
            rawData.put("requestBudget", this.requestBudget);

            // Structure our sub-nodes array maps objects
            List<Map<String, Object>> repoListMaps = new ArrayList<>();
            for (RepositoryConfig repo : this.repositories) {
                Map<String, Object> rMap = new LinkedHashMap<>();
                rMap.put("id", repo.getId());
                rMap.put("path", repo.getPath());
                rMap.put("sourceType", repo.getSourceType().name());
                rMap.put("status", repo.getStatus().name());
                rMap.put("lastIndexed",
                        repo.getLastIndexed() != null
                                ? repo.getLastIndexed().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME)
                                : null);
                repoListMaps.add(rMap);
            }
            rawData.put("repositories", repoListMaps);

            // Configure pretty printing styling formatting output constraints
            DumperOptions options = new DumperOptions();
            options.setDefaultFlowStyle(DumperOptions.FlowStyle.BLOCK);
            options.setPrettyFlow(true);
            Yaml yaml = new Yaml(options);

            try (FileWriter writer = new FileWriter(configPath.toFile())) {
                yaml.dump(rawData, writer);
            }
            log.debug("Successfully saved state alterations back to config.yml file.");
        } catch (Exception e) {
            log.error("Critical error encountered writing application property updates back to disk targets", e);
        }
    }

    // --- Accessor Getter and Setter Methods ---
    public String getGithubToken() {
        return githubToken;
    }

    public void setGithubToken(String token) {
        this.githubToken = token;
    }

    public String getAnthropicApiKey() {
        return anthropicApiKey;
    }

    public void setAnthropicApiKey(String anthropicApiKey) {
        this.anthropicApiKey = anthropicApiKey;
    }

    public String getWorkspaceDir() {
        return workspaceDir;
    }

    public void setWorkspaceDir(String dir) {
        this.workspaceDir = dir;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getProvider() {
        return provider;
    }

    public void setProvider(String provider) {
        this.provider = provider;
    }

    public int getRequestBudget() {
        return requestBudget;
    }

    public void setRequestBudget(int budget) {
        this.requestBudget = budget;
    }

    public List<RepositoryConfig> getRepositories() {
        return repositories;
    }
}
