package com.relay.orchestrator.connection;

import org.springframework.stereotype.Service;
import org.yaml.snakeyaml.DumperOptions;
import org.yaml.snakeyaml.Yaml;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;

/**
 * Reads/writes ~/.relay-orchestrator/config.yml. Deliberately simple - a
 * single file for a single local user, no database.
 */
@Service
public class ConnectionConfigService {

    private final Path configPath = resolveConfigPath();

    private static Path resolveConfigPath() {
        Path projectConfig = Path.of("config.yml").toAbsolutePath().normalize();
        if (Files.exists(projectConfig)) {
            return projectConfig;
        }
        return Path.of(System.getProperty("user.home"), ".relay-orchestrator", "config.yml");
    }

    private final Yaml yaml;

    public ConnectionConfigService() {
        DumperOptions options = new DumperOptions();
        options.setDefaultFlowStyle(DumperOptions.FlowStyle.BLOCK);
        options.setPrettyFlow(true);
        this.yaml = new Yaml(options);
    }

    public Optional<ConnectionConfig> load() {
        if (!Files.exists(configPath)) {
            return Optional.empty();
        }
        try (var reader = Files.newBufferedReader(configPath)) {
            Map<String, Object> data = yaml.load(reader);
            if (data == null) {
                return Optional.empty();
            }
            ConnectionConfig config = new ConnectionConfig();
            Object providerValue = data.getOrDefault("provider", ConnectionConfig.Provider.GITHUB_COPILOT.name());
            try {
                config.setProvider(ConnectionConfig.Provider.valueOf(String.valueOf(providerValue)));
            } catch (IllegalArgumentException e) {
                config.setProvider(ConnectionConfig.Provider.GITHUB_COPILOT);
            }
            config.setGithubToken(String.valueOf(data.getOrDefault("githubToken", "")));
            config.setAnthropicApiKey(String.valueOf(data.getOrDefault("anthropicApiKey", "")));
            config.setModel(String.valueOf(data.getOrDefault("model", "claude-sonnet-4.5")));
            config.setWorkspaceDir(String.valueOf(data.getOrDefault("workspaceDir", "")));
            Object budget = data.get("requestBudget");
            config.setRequestBudget(budget != null ? Integer.parseInt(String.valueOf(budget)) : 20);
            return Optional.of(config);
        } catch (IOException e) {
            throw new RuntimeException("Failed to read config at " + configPath, e);
        }
    }

    public void save(ConnectionConfig config) {
        try {
            Map<String, Object> data = new LinkedHashMap<>();
            if (Files.exists(configPath)) {
                try (var reader = Files.newBufferedReader(configPath)) {
                    Object existing = yaml.load(reader);
                    if (existing instanceof Map<?, ?> map) {
                        data.putAll((Map<String, Object>) map);
                    }
                }
            }

            data.put("provider", config.getProvider().name());
            data.put("githubToken", config.getGithubToken());
            data.put("anthropicApiKey", config.getAnthropicApiKey());
            data.put("model", config.getModel());
            data.put("workspaceDir", config.getWorkspaceDir());
            data.put("requestBudget", config.getRequestBudget());

            Files.createDirectories(configPath.getParent());
            try (var writer = Files.newBufferedWriter(configPath)) {
                yaml.dump(data, writer);
            }
        } catch (IOException e) {
            throw new RuntimeException("Failed to write config at " + configPath, e);
        }
    }
}
