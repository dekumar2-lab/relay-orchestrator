package com.relay.orchestrator.connection;

import com.relay.orchestrator.logging.LogBroadcaster;
import com.relay.orchestrator.logging.LogEvent;
import com.relay.orchestrator.logging.TokenTrackerService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientException;

import java.util.List;
import java.util.Map;

@Service
public class ClaudeApiConnectionChecker implements LlmConnectionChecker {

    private final LogBroadcaster broadcaster;
    private final ConnectionStatusService connectionStatusService;
    private final RestClient restClient = RestClient.create();

    private final TokenTrackerService tokenTrackerService;

    public ClaudeApiConnectionChecker(LogBroadcaster broadcaster, ConnectionStatusService connectionStatusService,
            TokenTrackerService tokenTrackerService) {
        this.broadcaster = broadcaster;
        this.connectionStatusService = connectionStatusService;
        this.tokenTrackerService = tokenTrackerService;
    }

    @Override
    public void validate(ConnectionConfig config) {
        try {
            if (config.getAnthropicApiKey() == null || config.getAnthropicApiKey().isBlank()) {
                broadcaster.publish(LogEvent.error(
                        "No Anthropic API key entered - create one at console.anthropic.com/settings/keys"));
                connectionStatusService.markFailure(config.getProvider().name());
                return;
            }

            broadcaster.publish(LogEvent.info("Validating Anthropic API key..."));
            broadcaster.publish(LogEvent.info("Sending test prompt to model: " + config.getModel()));
            String modelName = config.getModel();
            String targetModel = normalizeModelName(modelName);

            Map<?, ?> response = restClient.post()
                    .uri("https://api.anthropic.com/v1/messages")
                    .header("x-api-key", config.getAnthropicApiKey())
                    .header("anthropic-version", "2023-06-01")
                    .header("Content-Type", "application/json")
                    .body(Map.of(
                            "model", targetModel,
                            "max_tokens", 1,
                            "messages", List.of(Map.of(
                                    "role", "user",
                                    "content", List.of(Map.of(
                                            "type", "text",
                                            "text", "Reply with the single word OK"))))))
                    .retrieve()
                    .body(Map.class);

            if (response == null || response.get("content") == null) {
                broadcaster.publish(LogEvent.error("Anthropic API response was empty or malformed"));
                connectionStatusService.markFailure(config.getProvider().name());
                return;
            }

            if (response != null && response.containsKey("usage")) {
                Map<?, ?> usage = (Map<?, ?>) response.get("usage");
                int inputTokens = usage.get("input_tokens") != null ? ((Number) usage.get("input_tokens")).intValue()
                        : 0;
                int outputTokens = usage.get("output_tokens") != null ? ((Number) usage.get("output_tokens")).intValue()
                        : 0;

                // Log tracking usage metrics live
                tokenTrackerService.logAnthropicUsage("PROBE_CONN", targetModel, inputTokens, outputTokens);
            }

            String reply = extractReplyText(response);
            if (reply == null || reply.isBlank()) {
                broadcaster.publish(LogEvent.warn("Anthropic API responded without usable content"));
                connectionStatusService.markFailure(config.getProvider().name());
                return;
            }

            broadcaster.publish(LogEvent.success("Anthropic model replied: " + reply.trim()));
            broadcaster.publish(LogEvent.success("Connection validated - Claude API LLM is reachable"));
            connectionStatusService.markSuccess(config.getProvider().name());
        } catch (RestClientException e) {
            broadcaster.publish(LogEvent.error("Claude API check failed: " + e.getMessage()));
            connectionStatusService.markFailure(config.getProvider().name());
        } catch (Exception e) {
            broadcaster.publish(LogEvent.error("Claude API validation failed: " + e.getMessage()));
            connectionStatusService.markFailure(config.getProvider().name());
        }
    }

    private String normalizeModelName(String modelName) {
        // Force the checker to use the free-tier model to bypass the account balance
        // lockout
        return "claude-sonnet-5";
    }

    @SuppressWarnings("unchecked")
    private String extractReplyText(Map<?, ?> response) {
        Object content = response.get("content");
        if (!(content instanceof List<?> list)) {
            return null;
        }
        for (Object item : list) {
            if (item instanceof Map<?, ?> map) {
                Object text = map.get("text");
                if (text != null) {
                    return String.valueOf(text);
                }
            }
        }
        return null;
    }
}
