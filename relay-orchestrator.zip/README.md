# Relay Orchestrator — Phase 1: Connection Screen

## What this is

A local, single-user app with one screen: enter your GitHub token and a few
settings, click **Test Connection**, and watch the live log tail confirm
whether (1) the token itself is valid and (2) GitHub Copilot's LLM is
actually reachable and responding through it. No login, no repo indexing, no
story analysis yet — this build exists purely to prove the connection works
before anything else gets built on top of it.

## Prerequisites

1. **Java 17** and **Maven 3.9+**
2. **An active GitHub Copilot subscription** on the account the token belongs to
3. **The GitHub Copilot CLI installed locally** — the Java SDK drives this CLI
   process under the hood; it is not bundled:
   ```bash
   npm install -g @github/copilot
   copilot --version   # confirm it's on PATH
   ```
   Requires Node.js 22+ and npm 10+.
4. **A GitHub token with the right permission** — see "Getting your GitHub
   token" below. This is *not* the same as a generic PAT; it needs a specific
   permission or the Copilot check will fail even though the token itself is
   valid.

## Getting your GitHub token

1. Go to **github.com/settings/tokens?type=beta** (fine-grained tokens).
2. Click **Generate new token**.
3. Under **Resource owner**, select **your personal account** — not an
   organization. This permission is only available on user-owned tokens.
4. Under **Repository access**, any option works for this connection test
   (repo access isn't exercised yet — that comes with the indexing phase).
5. Under **Permissions**, click **Add permissions** and select
   **Copilot Requests**. This is the specific permission Copilot's API
   checks for — a token without it will pass the GitHub identity check but
   fail the Copilot check.
6. Click **Generate token** and copy it — you won't see it again.

## Field-by-field reference

| Field | What it's for | Where to get it / example |
|---|---|---|
| GitHub token | Authenticates both the GitHub identity check and the Copilot LLM call | From the steps above; looks like `github_pat_...` |
| Model | Which model Copilot should route the test prompt to | `claude-sonnet-4.5`, `gpt-5` — ask your Copilot admin if your org restricts choices |
| Workspace directory | Local folder for future scratch/clone use | Any existing, writable local path, e.g. `~/relay-orchestrator-workspace` |
| Request budget per run | Safety cap on Copilot requests per pipeline run | Default `20` is fine for now — not enforced yet, just stored |

## Running it

```bash
mvn spring-boot:run
```

Open **http://localhost:8080**. The Connection form loads (pre-filled from
`~/.relay-orchestrator/config.yml` if you've run it before).

## Test steps

1. Fill in the **GitHub token** field (required) and, ideally, a real
   **Workspace directory** path that exists on your machine.
2. Click **Test Connection**.
3. Watch the **Live Log** panel below the form — you should see, in order:
   ```
   [INFO]    Checking workspace directory...
   [SUCCESS] Workspace directory OK: /Users/you/relay-orchestrator-workspace
   [INFO]    Validating GitHub token...
   [SUCCESS] GitHub token valid - authenticated as <your-github-username>
   [INFO]    Checking Copilot access for <your-github-username>...
   [INFO]    Requires the Copilot CLI installed locally...
   [INFO]    Copilot CLI process started
   [INFO]    Sending test prompt to model: claude-sonnet-4.5
   [SUCCESS] Copilot replied: OK
   [SUCCESS] Connection validated - GitHub and Copilot LLM are both reachable
   ```
4. **That final "Connection validated" line is the actual proof** — it only
   appears if a real round-trip to the Copilot LLM succeeded and returned a
   real model response, not just that the token parsed correctly.

### Expected failure cases (test these too, to know the errors when they matter later)

| What you did | What you should see |
|---|---|
| Left the token blank | `[ERROR] No GitHub token entered...` — stops before touching the network |
| Used an expired/garbage token | `[ERROR] GitHub token check failed... 401 Unauthorized...` |
| Used a token *without* the "Copilot Requests" permission | GitHub check succeeds, then `[ERROR] Copilot check failed...` naming the likely cause |
| Copilot CLI not installed / not on PATH | `[ERROR] Copilot check failed...` — run `copilot --version` in a terminal to confirm it's findable |
| Pointed workspace directory at a path that doesn't exist | `[ERROR] Workspace directory does not exist or is not writable...` |

If you get the full success sequence above, the connection is genuinely
proven end to end — not just "the form saved."

## A note on the SDK itself

`com.github:copilot-sdk-java` is public preview (see the version comment in
`pom.xml`). If the project fails to compile on the `com.github.copilot.sdk.*`
imports, check the pinned version's Javadoc on Maven Central — the exact
class and method names shift between preview releases faster than most
libraries. The overall approach (explicit token → start the client → create
a session → send one prompt → read the reply) is what matters and should
hold even if specific method names move.

## Known limitations in this build

- The GitHub token is stored **in plain text** in
  `~/.relay-orchestrator/config.yml`. Acceptable for a local single-user
  tool; must change (encryption, or OS keychain integration) before any
  shared deployment.
- No repo indexing, no story analysis, no pipeline dashboard yet — this
  build is the Connection screen only.
- Request budget is stored but not yet enforced anywhere.

## What's next

The Repositories screen: a list of local repo paths, a structural indexer
(JavaParser) run per repo, and a workspace topology tree — the next slice
toward story analysis.
