package com.relay.orchestrator.logging;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.io.IOException;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Shared log-streaming infrastructure. Every pipeline stage built in later
 * phases (connection validation, repo indexing, story analysis, code
 * generation) publishes {@link LogEvent}s here instead of returning a single
 * response - the UI's live log tail is where results actually appear.
 *
 * Keeps a small replay buffer so a browser tab that connects (or reconnects)
 * after events were published still sees recent history instead of a blank
 * panel.
 */
@Component
public class LogBroadcaster {

    private static final Logger log = LoggerFactory.getLogger(LogBroadcaster.class);
    private static final int REPLAY_BUFFER_SIZE = 200;
    private static final long EMITTER_TIMEOUT_MS = 30 * 60 * 1000L; // 30 minutes

    private final List<SseEmitter> emitters = new CopyOnWriteArrayList<>();
    private final Deque<LogEvent> replayBuffer = new ArrayDeque<>();

    public synchronized SseEmitter subscribe() {
        SseEmitter emitter = new SseEmitter(EMITTER_TIMEOUT_MS);
        emitter.onCompletion(() -> emitters.remove(emitter));
        emitter.onTimeout(() -> emitters.remove(emitter));
        emitter.onError(ex -> emitters.remove(emitter));
        emitters.add(emitter);

        for (LogEvent buffered : replayBuffer) {
            sendTo(emitter, buffered);
        }
        return emitter;
    }

    public synchronized void publish(LogEvent event) {
        replayBuffer.addLast(event);
        while (replayBuffer.size() > REPLAY_BUFFER_SIZE) {
            replayBuffer.removeFirst();
        }
        for (SseEmitter emitter : emitters) {
            sendTo(emitter, event);
        }
    }

    private void sendTo(SseEmitter emitter, LogEvent event) {
        try {
            emitter.send(SseEmitter.event()
                    .name("logline")
                    .data(event.toHtmlRow()));
        } catch (IOException e) {
            log.debug("Removing dead log-tail subscriber: {}", e.getMessage());
            emitters.remove(emitter);
        }
    }
}
