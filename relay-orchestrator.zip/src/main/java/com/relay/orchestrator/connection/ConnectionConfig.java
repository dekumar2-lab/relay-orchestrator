package com.relay.orchestrator.connection;

/**
 * Phase 1 connection settings - persisted locally to
 * ~/.relay-orchestrator/config.yml. No login, single local user, so this is
 * one config for the whole app rather than per-user.
 */
public class ConnectionConfig {

    private String githubToken = "";
    private String model = "claude-sonnet-4.5";
    private String workspaceDir = "";
    private int requestBudget = 20;

    public String getGithubToken() {
        return githubToken;
    }

    public void setGithubToken(String githubToken) {
        this.githubToken = githubToken;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getWorkspaceDir() {
        return workspaceDir;
    }

    public void setWorkspaceDir(String workspaceDir) {
        this.workspaceDir = workspaceDir;
    }

    public int getRequestBudget() {
        return requestBudget;
    }

    public void setRequestBudget(int requestBudget) {
        this.requestBudget = requestBudget;
    }
}
