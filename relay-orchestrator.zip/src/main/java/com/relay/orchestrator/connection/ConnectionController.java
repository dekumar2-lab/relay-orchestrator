package com.relay.orchestrator.connection;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Controller
public class ConnectionController {

    private final ConnectionConfigService configService;
    private final CopilotConnectionService connectionService;

    // Single background worker: Phase 1 is single-user, single validation
    // run at a time is all that's needed. Revisit if this ever needs to
    // handle concurrent requests.
    private final ExecutorService executor = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "connection-test");
        t.setDaemon(true);
        return t;
    });

    public ConnectionController(ConnectionConfigService configService, CopilotConnectionService connectionService) {
        this.configService = configService;
        this.connectionService = connectionService;
    }

    @GetMapping("/")
    public String home(Model model) {
        ConnectionConfig config = configService.load().orElseGet(ConnectionConfig::new);
        model.addAttribute("config", config);
        return "connection";
    }

    @PostMapping("/connection/test")
    public ResponseEntity<Void> testConnection(@ModelAttribute ConnectionConfig formConfig) {
        configService.save(formConfig);
        executor.submit(() -> connectionService.validate(formConfig));
        return ResponseEntity.accepted().build();
    }
}
