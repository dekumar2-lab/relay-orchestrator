package com.relay.orchestrator.connection;

import org.springframework.stereotype.Service;
import org.yaml.snakeyaml.DumperOptions;
import org.yaml.snakeyaml.Yaml;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;

/**
 * Reads/writes ~/.relay-orchestrator/config.yml. Deliberately simple - a
 * single file for a single local user, no database. Phase 2 (deployed,
 * multi-user) will need per-user storage instead of this.
 *
 * Known limitation carried into this phase: the token is stored in plain
 * text on disk, readable by anything with access to this user account. Fine
 * for a local single-user tool; must change before any shared deployment.
 */
@Service
public class ConnectionConfigService {

    private final Path configPath = Path.of(System.getProperty("user.home"), ".relay-orchestrator", "config.yml");
    private final Yaml yaml;

    public ConnectionConfigService() {
        DumperOptions options = new DumperOptions();
        options.setDefaultFlowStyle(DumperOptions.FlowStyle.BLOCK);
        options.setPrettyFlow(true);
        this.yaml = new Yaml(options);
    }

    public Optional<ConnectionConfig> load() {
        if (!Files.exists(configPath)) {
            return Optional.empty();
        }
        try (var reader = Files.newBufferedReader(configPath)) {
            Map<String, Object> data = yaml.load(reader);
            if (data == null) {
                return Optional.empty();
            }
            ConnectionConfig config = new ConnectionConfig();
            config.setGithubToken(String.valueOf(data.getOrDefault("githubToken", "")));
            config.setModel(String.valueOf(data.getOrDefault("model", "claude-sonnet-4.5")));
            config.setWorkspaceDir(String.valueOf(data.getOrDefault("workspaceDir", "")));
            Object budget = data.get("requestBudget");
            config.setRequestBudget(budget != null ? Integer.parseInt(String.valueOf(budget)) : 20);
            return Optional.of(config);
        } catch (IOException e) {
            throw new RuntimeException("Failed to read config at " + configPath, e);
        }
    }

    public void save(ConnectionConfig config) {
        try {
            Files.createDirectories(configPath.getParent());
            Map<String, Object> data = new LinkedHashMap<>();
            data.put("githubToken", config.getGithubToken());
            data.put("model", config.getModel());
            data.put("workspaceDir", config.getWorkspaceDir());
            data.put("requestBudget", config.getRequestBudget());
            try (var writer = Files.newBufferedWriter(configPath)) {
                yaml.dump(data, writer);
            }
        } catch (IOException e) {
            throw new RuntimeException("Failed to write config at " + configPath, e);
        }
    }
}
